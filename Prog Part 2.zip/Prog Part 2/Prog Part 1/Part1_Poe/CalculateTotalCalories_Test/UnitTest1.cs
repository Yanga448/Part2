﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using RecipeApp;


namespace RecipeApp
{
    [TestClass]
    public class CalculateTotalCalories_Test
    {
        [TestMethod]
        public void TotalCaloriesCalculation_Test()
        {
            // Arrange
            var recipe = new Recipe();
            recipe.AddIngredient("Sugar", 100, "grams", 400, "Carbohydrates");
            recipe.AddIngredient("Butter", 50, "grams", 300, "Fats");

            // Act
            int totalCalories = 0;
            foreach (var ingredient in recipe.GetIngredients())
            {
                totalCalories += ingredient.Calories;
            }

            // Assert
            Assert.AreEqual(700, totalCalories);
        }
    }
}
