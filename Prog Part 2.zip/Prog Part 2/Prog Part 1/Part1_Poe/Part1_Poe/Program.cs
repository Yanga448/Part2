﻿using System;

namespace RecipeApp
{
    class Program
    {
        // Entry point of the program
        static void Main(string[] args)
        {
            // Create an instance of RecipeApp and start the application
            RecipeApp recipeApp = new RecipeApp();
            recipeApp.StartApp();
        }
    }
}
